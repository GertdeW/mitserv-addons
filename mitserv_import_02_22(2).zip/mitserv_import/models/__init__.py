# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import sale
from . import mail_thread
from . import helpdesk
from . import res_partner
from . import res_config_settings
from . import mail_composer
from . import project
from . import account
