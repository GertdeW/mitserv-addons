# -*- coding: utf-8 -*-

from . import support_team
from . import type_of_subject
from . import ticket_type
from . import helpdesk_stage
from . import helpdesk_support
from . import support_invoice
from . import ticket_task
from . import analytic_account

from . import res_partner
from . import project
from . import project_task
from . import analytic_account_line

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
