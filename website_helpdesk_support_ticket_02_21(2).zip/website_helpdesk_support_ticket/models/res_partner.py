# -*- coding: utf-8 -*

from odoo import models, fields

class CustomerPrice(models.Model):
    _inherit = 'res.partner'
    
    price_rate = fields.Float(
        string='Price / Rate (Company Currency)',
        default=0.0,
        copy=False,
    )
    
